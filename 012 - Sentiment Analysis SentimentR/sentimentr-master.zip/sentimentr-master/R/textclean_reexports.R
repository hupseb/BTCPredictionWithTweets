#' @importFrom textclean replace_grade
#' @export
textclean::replace_grade

#' @importFrom textclean replace_rating
#' @export
textclean::replace_rating

#' @importFrom textclean replace_emoticon
#' @export
textclean::replace_emoticon
