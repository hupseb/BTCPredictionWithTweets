library("testthat")
library("sentimentr")

test_check("sentimentr")