library(staticdocs)

sd_section("",
  "Function for...",
  c(
      "myfun"
  )
)